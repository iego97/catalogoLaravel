<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Crear mascota</title>
</head>
<body>
    <form action="<?php echo e(route('mascotas.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <label >Especie</label>
            <select name="especie" required>
                <option disabled selected value="">Elige una especie</option>
                <?php $__currentLoopData = $especies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $especie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($especie->id); ?>"><?php echo e($especie->nombre); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </select>
        
        <br/>
        <label>Nombre</label>
        <input required type="text" name="nombre" placeholder="nombre de la mascota">
        <br/>
        <label >Precio</label>
        <input required type="text" name="precio" placeholder="Precio de la mascota">
        <br/>
        <label >Fecha de nacimiento</label>
        <input required type="date" name="nacimiento">
        <br/>
        <button type="submit">Crear nueva mascota</button> 


    </form>
</body>
</html>