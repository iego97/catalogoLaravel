<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Lista de mascotas</title>
</head>
<body>

    <a href="<?php echo e(route('mascotas.create')); ?>">
    <button>Agregar Mascotas</button>
    </a>


<table>
    <thead>
    <tr>
        <th>Nombre</th>
        <th>Precio</th>
        <th>Acciones</th>
    <tr>
        <tbody>
                <?php $__currentLoopData = $mascotas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mascota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($mascota->nombre); ?></td>
                        <td><?php echo e($mascota->precio); ?> </td>
                        <td>
                            <a href="<?php echo e(route('mascotas.edit',$mascota->id)); ?>">
                            <button>Editar</button>
                            </a>
                            <button>Borrar</button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        </tbody>
    </thead>

</table>

</body>
</html>